<?php
    $db = mysqli_connect('localhost', 'root', '', 'baysix_swiftlogistics');
?>